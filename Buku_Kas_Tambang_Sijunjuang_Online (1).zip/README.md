# Buku Kas Tambang Sijunjuang
## Versi Online + Local Storage + Home + Login Admin/Viewer + Supabase

### Struktur
- index.html
- style.css
- script.js
- config.js
- supabase.sql

### 1. Buat project Supabase
Buat project baru di Supabase, lalu buka SQL Editor dan jalankan seluruh isi `supabase.sql`.

### 2. Buat akun
Di Authentication -> Users:
- buat 1 akun admin dengan email/password.
- bila perlu buat beberapa akun viewer untuk HP/komputer lain.

Setelah akun admin dibuat, jalankan SQL:
update public.profiles p
set role='admin'
from auth.users u
where p.id=u.id and u.email='EMAIL_ADMIN_ANDA';

### 3. Isi config.js
Isi:
window.SUPABASE_CONFIG = {
  url: "https://PROJECT-ANDA.supabase.co",
  key: "PUBLISHABLE_ATAU_ANON_KEY"
};

Gunakan publishable/anon key saja. Jangan pernah memasukkan secret/service_role key ke browser.

### 4. Hosting gratis
Untuk situs statis, upload file ini ke repository GitHub lalu aktifkan GitHub Pages.
Pastikan `index.html` berada di folder yang dipublikasikan.

### 5. Cara kerja
- Admin login -> bisa tambah/edit/hapus.
- Viewer login -> hanya melihat.
- Semua perangkat yang login ke project Supabase yang sama memakai database yang sama.
- Local Storage menyimpan cache terakhir di masing-masing HP/komputer.
- Jika internet putus, data terakhir masih dapat dilihat.
- Backup JSON dapat dipakai untuk cadangan lokal.
- Realtime diaktifkan pada tabel produksi dan keuangan.

### Catatan keamanan
RLS pada supabase.sql membatasi perubahan data hanya untuk role admin.
Jangan pernah menaruh secret/service_role key pada file frontend.
