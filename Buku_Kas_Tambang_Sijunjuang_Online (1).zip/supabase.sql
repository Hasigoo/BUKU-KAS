-- =========================================================
-- SUPABASE DATABASE: BUKU KAS TAMBANG SIJUNJUANG
-- Jalankan seluruh SQL ini di Supabase SQL Editor.
-- =========================================================

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'viewer' check (role in ('admin','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.produksi (
  id uuid primary key default gen_random_uuid(),
  tanggal date not null,
  nama_barang text not null,
  produksi_kg numeric(14,2) not null default 0 check (produksi_kg >= 0),
  terjual_kg numeric(14,2) not null default 0 check (terjual_kg >= 0 and terjual_kg <= produksi_kg),
  keterangan text not null default '',
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);

create table if not exists public.keuangan (
  id uuid primary key default gen_random_uuid(),
  tanggal date not null,
  jenis text not null check (jenis in ('masuk','keluar')),
  kategori text not null,
  jumlah numeric(18,2) not null default 0 check (jumlah >= 0),
  keterangan text not null default '',
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  new.updated_by = auth.uid();
  return new;
end;
$$;

drop trigger if exists trg_produksi_updated_at on public.produksi;
create trigger trg_produksi_updated_at
before update on public.produksi
for each row execute function public.set_updated_at();

drop trigger if exists trg_keuangan_updated_at on public.keuangan;
create trigger trg_keuangan_updated_at
before update on public.keuangan
for each row execute function public.set_updated_at();

-- Buat profile otomatis saat user Auth baru dibuat.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, role)
  values (new.id, 'viewer')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.produksi enable row level security;
alter table public.keuangan enable row level security;

drop policy if exists "profile own read" on public.profiles;
create policy "profile own read" on public.profiles
for select to authenticated
using (id = auth.uid());

drop policy if exists "authenticated read produksi" on public.produksi;
create policy "authenticated read produksi" on public.produksi
for select to authenticated
using (true);

drop policy if exists "admin insert produksi" on public.produksi;
create policy "admin insert produksi" on public.produksi
for insert to authenticated
with check (public.is_admin());

drop policy if exists "admin update produksi" on public.produksi;
create policy "admin update produksi" on public.produksi
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "admin delete produksi" on public.produksi;
create policy "admin delete produksi" on public.produksi
for delete to authenticated
using (public.is_admin());

drop policy if exists "authenticated read keuangan" on public.keuangan;
create policy "authenticated read keuangan" on public.keuangan
for select to authenticated
using (true);

drop policy if exists "admin insert keuangan" on public.keuangan;
create policy "admin insert keuangan" on public.keuangan
for insert to authenticated
with check (public.is_admin());

drop policy if exists "admin update keuangan" on public.keuangan;
create policy "admin update keuangan" on public.keuangan
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "admin delete keuangan" on public.keuangan;
create policy "admin delete keuangan" on public.keuangan
for delete to authenticated
using (public.is_admin());

-- Hak akses Data API.
grant select on public.profiles to authenticated;
grant select, insert, update, delete on public.produksi to authenticated;
grant select, insert, update, delete on public.keuangan to authenticated;

-- Realtime agar perubahan dari HP/komputer lain bisa muncul.
do $$
begin
  begin
    alter publication supabase_realtime add table public.produksi;
  exception when duplicate_object then null;
  end;
  begin
    alter publication supabase_realtime add table public.keuangan;
  exception when duplicate_object then null;
  end;
end $$;

-- =========================================================
-- SETELAH MEMBUAT USER ADMIN DI AUTH:
--
-- 1. Buka Authentication -> Users dan buat user email/password.
-- 2. Jalankan:
--
-- update public.profiles p
-- set role = 'admin'
-- from auth.users u
-- where p.id = u.id
--   and u.email = 'EMAIL_ADMIN_ANDA';
--
-- User lain yang dibuat otomatis menjadi viewer.
-- =========================================================
